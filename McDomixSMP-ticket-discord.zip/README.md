# McDomixSMP su bendru Chat

Sukurta pagal viešai matomą https://playmcdomixweb.netlify.app/ puslapio struktūrą. Tai naujai parašyta svetainės versija, ne originalių šaltinio failų kopija.

## Įkėlimas į Netlify

**Svarbu:** šis projektas naudoja Netlify Functions ir Netlify Blobs. Paprastas `index.html` ar ZIP nutempimas į Netlify Drop gali nesukurti funkcijų ir neįdiegti priklausomybių. Rekomenduojamas būdas:

1. Išarchyvuok ZIP ir įkelk visą aplanką į GitHub saugyklą (įskaitant `package.json`, `netlify.toml`, `netlify/functions/api.mjs`).
2. Netlify pasirink **Add new project → Import an existing project → GitHub** ir pasirink saugyklą.
3. Build command gali likti tuščias; publish directory yra `.`; Functions directory `netlify/functions` (nustatyta `netlify.toml`). Netlify turi įdiegti `@netlify/blobs` priklausomybę.
4. Netlify **Project configuration → Environment variables** pridėk `ADMIN_PASSWORD` ir savo naują, unikalų slaptažodį. Jo nedėk į HTML ar GitHub. Saugok kaip secret, jei planas leidžia.
5. Deploy ir patikrink `https://TAVO-ADRESAS.netlify.app/.netlify/functions/api?action=chat` – turi grąžinti JSON su `messages`.
6. Jei nori išlaikyti esamą Netlify adresą, prijunk GitHub saugyklą prie **esamo** Netlify projekto, o ne kurk kitą tuo pačiu pavadinimu.

## Funkcijos
- Viešas chat: visi gali skaityti, rašyti su įvestu Minecraft vardu; 5 s atnaujinimas.
- Help: privačios užklausos, atsakymai rodomi tame pačiame įrenginyje (vietinis užklausos tokenas).
- Admin: serverio pusėje tikrinamas `ADMIN_PASSWORD`, Help atsakymai ir chat moderavimas.
- Discord: `https://discord.gg/WuSYedn4` visose Discord / pirkimo / verification nuorodose.
- MC IP: `play.mcdomix.com` (perimtas iš dabartinio viešo puslapio; pakeisk, jei netikslus).

## Svarbu
Minecraft username **nėra patvirtinamas** su Mojang/Microsoft – bet kuris lankytojas gali įrašyti svetimą vardą. Chat turi bazinį 4 s dažnio apribojimą, tačiau tai nėra pilna anti-spam sistema. Naudojamas bendras JSON sąrašas Netlify Blobs; dideliam srautui reikėtų atskiros duomenų bazės su atominiu įrašymu, prisijungimo patvirtinimu ir stipresne moderacija. Netlify Blobs pasiekiamumas priklauso nuo Netlify projekto ir diegimo konfigūracijos.

Jeigu slaptažodis buvo atskleistas pokalbyje, pakeisk jį į naują.


ATNAUJINIMAS: Paslaugos rodomos tik sukurtos Admin panelėje. Balanso papildymas yra atskira skiltis po Paslaugomis. Discord kvietimo blokas yra pačiame puslapio apačioje, po Chat.
