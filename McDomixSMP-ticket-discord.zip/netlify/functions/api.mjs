import { getStore } from '@netlify/blobs';
import { randomUUID, timingSafeEqual } from 'node:crypto';
const json=(data,status=200)=>({statusCode:status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'},body:JSON.stringify(data)});
const equal=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y)};
const parse=e=>{try{return JSON.parse(e.body||'{}')}catch{return {}}};
const clean=(s,n)=>String(s||'').trim().slice(0,n);
const nickOK=s=>/^[A-Za-z0-9_]{3,16}$/.test(s);
const admin=e=>!!process.env.ADMIN_PASSWORD&&equal(e.headers['x-admin-password']||'',process.env.ADMIN_PASSWORD);
export const handler=async e=>{
 try{
 const store=getStore('mcdomix-data');const p=e.queryStringParameters||{},b=parse(e),action=p.action||'';
 const load=async(key)=>await store.get(key,{type:'json'})||[];
 if(action==='services'&&e.httpMethod==='GET')return json({services:await load('services')});
 if(action==='service-save'&&e.httpMethod==='POST'){
  if(!admin(e))return json({error:'Nėra prieigos.'},401);
  const title=clean(b.title,70),description=clean(b.description,500),price=clean(b.price,40);
  if(!title||!description)return json({error:'Įvesk pavadinimą ir aprašymą.'},400);
  const services=await load('services');
  if(b.id){const item=services.find(s=>s.id===b.id);if(!item)return json({error:'Paslauga nerasta.'},404);Object.assign(item,{title,description,price})}
  else services.push({id:randomUUID(),title,description,price});
  await store.setJSON('services',services.slice(-100));return json({ok:true});
 }
 if(action==='service-delete'&&e.httpMethod==='POST'){
  if(!admin(e))return json({error:'Nėra prieigos.'},401);
  const services=await load('services');await store.setJSON('services',services.filter(s=>s.id!==b.id));return json({ok:true});
 }
 if(action==='chat'&&e.httpMethod==='GET')return json({messages:(await load('chat')).slice(-100)});
 if(action==='chat'&&e.httpMethod==='POST'){
  const name=clean(b.name,16),message=clean(b.message,300);
  if(!nickOK(name)||!message)return json({error:'Minecraft vardas turi būti 3–16 simbolių, o žinutė negali būti tuščia.'},400);
  if(String(b.message||'').length>300)return json({error:'Žinutė per ilga.'},400);
  const now=Date.now(),rateKey='rate-'+(e.headers['x-nf-client-connection-ip']||e.headers['client-ip']||'unknown').replace(/[^\w.:-]/g,'').slice(0,80);
  const last=Number(await store.get(rateKey)||0);if(now-last<4000)return json({error:'Palauk 4 sekundes prieš kitą žinutę.'},429);
  await store.set(rateKey,String(now));const messages=await load('chat');messages.push({id:randomUUID(),name,message,time:new Date().toISOString()});await store.setJSON('chat',messages.slice(-100));return json({ok:true});
 }
 if(action==='help'&&e.httpMethod==='POST'){
  const name=clean(b.name,16),message=clean(b.message,1000),token=clean(b.token,100);
  if(!nickOK(name)||!message)return json({error:'Įvesk teisingą Minecraft vardą ir žinutę.'},400);
  const tickets=await load('tickets');const id=randomUUID();const secret=randomUUID();tickets.push({id,token:secret,name,messages:[{from:'player',text:message,time:new Date().toISOString()}],created:new Date().toISOString()});await store.setJSON('tickets',tickets.slice(-300));return json({id,token:secret});
 }
 if(action==='help'&&e.httpMethod==='GET'){
  const tickets=await load('tickets');const ticket=tickets.find(t=>t.id===p.id&&t.token===p.token);return ticket?json({ticket:{id:ticket.id,name:ticket.name,messages:ticket.messages}}):json({error:'Užklausa nerasta.'},404);
 }
 if(action==='admin'&&e.httpMethod==='GET'){
  if(!process.env.ADMIN_PASSWORD)return json({error:'Netlify aplinkoje nenustatytas ADMIN_PASSWORD.'},503);
  if(!admin(e))return json({error:'Neteisingas administratoriaus kodas.'},401);
  const tickets=await load('tickets');return json({tickets:tickets.map(({token,...t})=>t)});
 }
 if(action==='reply'&&e.httpMethod==='POST'){
  if(!admin(e))return json({error:'Nėra prieigos.'},401);
  const tickets=await load('tickets'),t=tickets.find(x=>x.id===b.id),message=clean(b.message,1000);if(!t||!message)return json({error:'Nerasta užklausa arba žinutė.'},400);
  t.messages.push({from:'admin',text:message,time:new Date().toISOString()});await store.setJSON('tickets',tickets);return json({ok:true});
 }
 if(action==='delete'&&e.httpMethod==='POST'){
  if(!admin(e))return json({error:'Nėra prieigos.'},401);
  if(b.type==='chat'){const msgs=await load('chat');await store.setJSON('chat',msgs.filter(m=>m.id!==b.id));return json({ok:true})}
  if(b.type==='ticket'){const tickets=await load('tickets');await store.setJSON('tickets',tickets.filter(t=>t.id!==b.id));return json({ok:true})}
 }
 return json({error:'Nerastas veiksmas.'},404);
 }catch(err){console.error(err);return json({error:'Serverio klaida. Patikrink Netlify Functions ir Blobs nustatymus.'},500)}
};
